#include "leveldb/db.h"
#include <cstdio>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
using namespace leveldb;

vector<string> testSplit(string srcStr, const string& delim);

int main() {
    DB* db = nullptr;
    Options op;
    op.create_if_missing = true;
    Status status = DB::Open(op, "testdb", &db);
    assert(status.ok());

    //读取文件1
    freopen("./test/input1","r", stdin);
    string key, value;
    for(int t=0; t<10; t++) {
       cin >> key >> value;
       db->Put(WriteOptions(), key, value);
    }
    fclose(stdin);

    ReadOptions options;
    options.snapshot = db->GetSnapshot();

    cin.clear();

    //读取文件2
    freopen("./test/input2","r", stdin);
    for(int t=0; t<10; t++) {
        cin >> key >> value;
        db->Put(WriteOptions(), key, value);
    }
    fclose(stdin);


    //写入文件
    freopen("./test/output","w",stdout);
    string s[15];
    int i=0;
    Iterator* iter = db->NewIterator(options);
    for(iter->SeekToFirst(); iter->Valid(); iter->Next())
    {
        s[i] = iter->key().ToString() + " " + iter->value().ToString() + " ";
        i++;

    }

    Iterator* iter1 = db->NewIterator(ReadOptions());
    i=0;
    for(iter1->SeekToFirst(); iter1->Valid(); iter1->Next())
    {
        s[i] += iter1->value().ToString();
        cout << s[i] << endl;
        i++;
    }
    fclose(stdout);

    delete iter;
    delete iter1;
    db->ReleaseSnapshot(options.snapshot);

    delete db;
    return 0;
}



vector<string> testSplit(string srcStr, const string& delim)
{
    int nPos = 0;
    vector<string> vec;
    nPos = srcStr.find(delim.c_str());
    while(-1 != nPos)
    {
        string temp = srcStr.substr(0, nPos);
        vec.push_back(temp);
        srcStr = srcStr.substr(nPos+1);
        nPos = srcStr.find(delim.c_str());
    }
    vec.push_back(srcStr);
    return vec;
}